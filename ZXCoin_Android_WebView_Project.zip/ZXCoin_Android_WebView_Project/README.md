ZX COIN — Android Step 1

The frozen STEP 8 User App is copied unchanged into:
app/src/main/assets/index.html

This is the Android WebView project source. Build it with Android Studio/Gradle to create the APK.
The original frozen HTML remains untouched.
